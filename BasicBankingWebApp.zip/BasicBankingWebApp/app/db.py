import sqlite3
from flask import current_app, g


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS accounts (
            account_number TEXT PRIMARY KEY,
            holder_name TEXT NOT NULL,
            balance_paise INTEGER NOT NULL DEFAULT 0 CHECK (balance_paise >= 0),
            created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        );

        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_number TEXT NOT NULL,
            transaction_type TEXT NOT NULL CHECK (transaction_type IN ('Deposit', 'Withdrawal')),
            amount_paise INTEGER NOT NULL CHECK (amount_paise > 0),
            balance_after_paise INTEGER NOT NULL CHECK (balance_after_paise >= 0),
            remarks TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (account_number) REFERENCES accounts(account_number)
        );
        CREATE INDEX IF NOT EXISTS idx_transactions_account
            ON transactions(account_number, id DESC);
    """)
    db.commit()


def init_app(app):
    app.teardown_appcontext(close_db)

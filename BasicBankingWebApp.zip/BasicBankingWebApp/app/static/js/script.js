document.addEventListener("DOMContentLoaded", () => {
  const menuButton = document.getElementById("mobile-menu");
  const sidebar = document.getElementById("sidebar");

  if (menuButton && sidebar) {
    menuButton.addEventListener("click", () => sidebar.classList.toggle("open"));
  }

  document.querySelectorAll(".flash-close").forEach((button) => {
    button.addEventListener("click", () => button.closest(".flash")?.remove());
  });

  const tableSearch = document.getElementById("table-search");
  const table = document.getElementById("accounts-table");
  if (tableSearch && table) {
    tableSearch.addEventListener("input", () => {
      const query = tableSearch.value.toLowerCase().trim();
      table.querySelectorAll("tbody tr").forEach((row) => {
        row.hidden = !row.innerText.toLowerCase().includes(query);
      });
    });
  }

  document.querySelectorAll("form[data-confirm]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      const action = form.dataset.confirm;
      const amount = form.querySelector('[name="amount"]')?.value;
      if (amount && Number(amount) > 0) {
        const message = action === "withdraw"
          ? `Confirm withdrawal of ₹${Number(amount).toFixed(2)}?`
          : `Confirm deposit of ₹${Number(amount).toFixed(2)}?`;
        if (!window.confirm(message)) event.preventDefault();
      }
    });
  });
});

import os
from flask import Flask
from .db import init_app


def create_app():
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("SECRET_KEY", "change-this-development-secret"),
        DATABASE=os.path.join(app.instance_path, "banking.db"),
    )

    os.makedirs(app.instance_path, exist_ok=True)
    init_app(app)

    from .routes import bp
    app.register_blueprint(bp)

    with app.app_context():
        from .db import init_db
        init_db()

    return app

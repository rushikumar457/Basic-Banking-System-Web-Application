import sqlite3
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from flask import Blueprint, flash, redirect, render_template, request, url_for
from .db import get_db

bp = Blueprint("main", __name__)


def money_to_paise(raw):
    """Parse a positive rupee amount into integer paise."""
    try:
        amount = Decimal((raw or "").strip())
        if not amount.is_finite() or amount <= 0:
            return None
        amount = amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return int(amount * 100)
    except (InvalidOperation, ValueError, TypeError):
        return None


def rupees(paise):
    return f"{(paise or 0) / 100:,.2f}"


def get_account(search):
    db = get_db()
    search = (search or "").strip()
    if not search:
        return None
    row = db.execute(
        "SELECT * FROM accounts WHERE account_number = ?", (search,)
    ).fetchone()
    if row:
        return row
    matches = db.execute(
        "SELECT * FROM accounts WHERE lower(holder_name) = lower(?) ORDER BY account_number",
        (search,),
    ).fetchall()
    return matches[0] if len(matches) == 1 else None


@bp.app_context_processor
def inject_helpers():
    return {"rupees": rupees}


@bp.route("/")
def index():
    db = get_db()
    total_accounts = db.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
    total_paise = db.execute("SELECT COALESCE(SUM(balance_paise), 0) FROM accounts").fetchone()[0]
    recent = db.execute("""
        SELECT t.*, a.holder_name FROM transactions t
        JOIN accounts a ON a.account_number = t.account_number
        ORDER BY t.id DESC LIMIT 5
    """).fetchall()
    return render_template(
        "index.html",
        total_accounts=total_accounts,
        total_balance=total_paise,
        recent=recent,
    )


@bp.route("/accounts/create", methods=["GET", "POST"])
def create_account():
    if request.method == "POST":
        name = request.form.get("holder_name", "").strip()
        initial_paise = 0
        initial_raw = request.form.get("initial_balance", "0").strip()

        if not name or len(name) > 100:
            flash("Enter an account holder name (maximum 100 characters).", "error")
            return render_template("create_account.html")
        try:
            initial = Decimal(initial_raw or "0")
            if not initial.is_finite() or initial < 0:
                raise InvalidOperation
            initial = initial.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            initial_paise = int(initial * 100)
        except (InvalidOperation, ValueError):
            flash("Enter a valid initial balance of ₹0 or more.", "error")
            return render_template("create_account.html")

        db = get_db()
        try:
            # Generate a unique 10-digit account number.
            last = db.execute(
                "SELECT MAX(CAST(account_number AS INTEGER)) FROM accounts"
            ).fetchone()[0]
            account_number = str(max(1000000000, last or 999999999) + 1)
            db.execute(
                "INSERT INTO accounts (account_number, holder_name, balance_paise) VALUES (?, ?, ?)",
                (account_number, name, initial_paise),
            )
            if initial_paise > 0:
                db.execute(
                    """INSERT INTO transactions
                    (account_number, transaction_type, amount_paise, balance_after_paise, remarks)
                    VALUES (?, 'Deposit', ?, ?, 'Opening balance')""",
                    (account_number, initial_paise, initial_paise),
                )
            db.commit()
        except sqlite3.Error:
            db.rollback()
            flash("Could not create the account. Please try again.", "error")
            return render_template("create_account.html")

        flash(f"Account created successfully. Account number: {account_number}", "success")
        return redirect(url_for("main.accounts"))

    return render_template("create_account.html")


@bp.route("/balance", methods=["GET", "POST"])
def balance():
    account = None
    query = ""
    if request.method == "POST":
        query = request.form.get("search", "").strip()
        account = get_account(query)
        if not account:
            flash("Account not found, or the name matches multiple accounts. Try the account number.", "error")
    return render_template("balance.html", account=account, query=query)


def perform_transaction(transaction_type):
    search = request.form.get("search", "").strip()
    amount_paise = money_to_paise(request.form.get("amount", ""))
    if not search:
        flash("Enter an account number or a unique holder name.", "error")
        return None
    if amount_paise is None:
        flash("Enter an amount greater than ₹0.00.", "error")
        return None

    db = get_db()
    try:
        # Begin an immediate transaction to avoid two withdrawals racing each other.
        db.execute("BEGIN IMMEDIATE")
        account = db.execute(
            "SELECT * FROM accounts WHERE account_number = ?", (search,)
        ).fetchone()
        if account is None:
            matches = db.execute(
                "SELECT * FROM accounts WHERE lower(holder_name) = lower(?) ORDER BY account_number",
                (search,),
            ).fetchall()
            if len(matches) != 1:
                db.rollback()
                flash("Account not found or name is not unique. Use the account number.", "error")
                return None
            account = matches[0]

        current = account["balance_paise"]
        if transaction_type == "Withdrawal" and amount_paise > current:
            db.rollback()
            flash(f"Insufficient balance. Available balance: ₹{rupees(current)}.", "error")
            return None

        new_balance = current + amount_paise if transaction_type == "Deposit" else current - amount_paise
        db.execute(
            "UPDATE accounts SET balance_paise = ? WHERE account_number = ?",
            (new_balance, account["account_number"]),
        )
        db.execute(
            """INSERT INTO transactions
            (account_number, transaction_type, amount_paise, balance_after_paise, remarks)
            VALUES (?, ?, ?, ?, ?)""",
            (account["account_number"], transaction_type, amount_paise, new_balance,
             f"{transaction_type} through web app"),
        )
        db.commit()
        flash(
            f"{transaction_type} successful: ₹{rupees(amount_paise)}. New balance: ₹{rupees(new_balance)}.",
            "success",
        )
        return account["account_number"]
    except sqlite3.Error:
        db.rollback()
        flash("The transaction could not be completed. Please try again.", "error")
        return None


@bp.route("/deposit", methods=["GET", "POST"])
def deposit():
    if request.method == "POST":
        account_number = perform_transaction("Deposit")
        if account_number:
            return redirect(url_for("main.history", search=account_number))
    return render_template("transaction.html", action="Deposit", color="green")


@bp.route("/withdraw", methods=["GET", "POST"])
def withdraw():
    if request.method == "POST":
        account_number = perform_transaction("Withdrawal")
        if account_number:
            return redirect(url_for("main.history", search=account_number))
    return render_template("transaction.html", action="Withdraw", color="red")


@bp.route("/accounts")
def accounts():
    rows = get_db().execute(
        "SELECT * FROM accounts ORDER BY account_number"
    ).fetchall()
    return render_template("accounts.html", accounts=rows)


@bp.route("/highest")
def highest():
    account = get_db().execute(
        "SELECT * FROM accounts ORDER BY balance_paise DESC, account_number ASC LIMIT 1"
    ).fetchone()
    return render_template("highest_balance.html", account=account)


@bp.route("/history")
def history():
    search = request.args.get("search", "").strip()
    account = get_account(search) if search else None
    transactions = []
    if account:
        transactions = get_db().execute(
            """SELECT * FROM transactions
            WHERE account_number = ? ORDER BY id DESC LIMIT 100""",
            (account["account_number"],),
        ).fetchall()
    elif search:
        flash("Account not found, or the name matches multiple accounts.", "error")
    return render_template(
        "history.html", search=search, account=account, transactions=transactions
    )

import os
import tempfile
import unittest
from app import create_app


class BankingWebTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.temp_dir.name, "test.db")
        self.app = create_app()
        self.app.config.update(TESTING=True, DATABASE=self.db_path)
        self.client = self.app.test_client()

    def tearDown(self):
        self.temp_dir.cleanup()

    def create_account(self, name="Test User", balance="100.00"):
        return self.client.post("/accounts/create", data={
            "holder_name": name,
            "initial_balance": balance,
        }, follow_redirects=True)

    def test_dashboard_loads(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Dashboard", response.data)

    def test_create_account_and_persist(self):
        response = self.create_account()
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Test User", response.data)
        self.assertIn(b"1000000001", response.data)

    def test_deposit_and_withdraw(self):
        self.create_account()
        response = self.client.post("/deposit", data={
            "search": "1000000001", "amount": "25.50"
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"125.50", response.data)

        response = self.client.post("/withdraw", data={
            "search": "1000000001", "amount": "25.50"
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"100.00", response.data)

    def test_insufficient_balance_rejected(self):
        self.create_account(balance="10")
        response = self.client.post("/withdraw", data={
            "search": "1000000001", "amount": "11"
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Insufficient balance", response.data)

    def test_negative_deposit_rejected(self):
        self.create_account()
        response = self.client.post("/deposit", data={
            "search": "1000000001", "amount": "-5"
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"greater than", response.data)


if __name__ == "__main__":
    unittest.main()
